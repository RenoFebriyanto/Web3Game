// Assets/Script/Level/FragmentPrefabRegistry.cs
using System;
using UnityEngine;

[Serializable]
public struct FragmentPrefabEntry
{
    public FragmentType type;
    [Tooltip("variant index, 0..2")]
    public int variant;
    public GameObject prefab;
}

[CreateAssetMenu(menuName = "Kulino/FragmentPrefabRegistry", fileName = "FragmentPrefabRegistry")]
public class FragmentPrefabRegistry : ScriptableObject
{
    public FragmentPrefabEntry[] entries;

    public GameObject GetPrefab(FragmentType type, int variant)
    {
        foreach (var e in entries)
        {
            if (e.type == type && e.variant == variant && e.prefab != null)
                return e.prefab;
        }

        foreach (var e in entries)
        {
            if (e.type == type && e.prefab != null)
                return e.prefab;
        }

        Debug.LogWarning($"Missing prefab for {type} variant {variant}");
        return null;
    }
}