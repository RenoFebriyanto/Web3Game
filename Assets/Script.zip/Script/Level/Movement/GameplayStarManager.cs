﻿using UnityEngine;
using UnityEngine.Events;
using TMPro;

/// <summary>
/// ✅ FIXED: GameplayStarManager - Remove direct call to KulinoCoinRewardSystem
/// Manager untuk tracking bintang yang dikumpulkan di gameplay.
/// </summary>
public class GameplayStarManager : MonoBehaviour
{
    public static GameplayStarManager Instance { get; private set; }

    [Header("Star Settings")]
    public int totalStarsInLevel = 3;

    [Header("UI")]
    public TextMeshProUGUI starText;

    [Header("Events")]
    public UnityEvent<int> OnStarCollected;
    public UnityEvent<int> OnLevelComplete;

    private int collectedStars = 0;
    private bool levelCompleted = false;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    public void CollectStar(int amount = 1)
    {
        if (levelCompleted) return;

        collectedStars += amount;
        collectedStars = Mathf.Clamp(collectedStars, 0, totalStarsInLevel);

        starText.text = $"{collectedStars}/{totalStarsInLevel}";

        Debug.Log($"[GameplayStarManager] Star collected! Total: {collectedStars}/{totalStarsInLevel}");

        OnStarCollected?.Invoke(collectedStars);
    }

    /// <summary>
    /// ✅ UPDATED: CompleteLevelWithStars - KulinoCoinRewardSystem sudah auto-subscribe
    /// </summary>
    /// <summary>
/// ✅ UPDATED: Save gameplay coins saat level complete
/// </summary>
public void CompleteLevelWithStars()
{
    if (levelCompleted) return;
    levelCompleted = true;

    string levelId = PlayerPrefs.GetString("SelectedLevelId", "");
    int levelNum = PlayerPrefs.GetInt("SelectedLevelNumber", 1);

    if (!string.IsNullOrEmpty(levelId) && LevelProgressManager.Instance != null)
    {
        LevelProgressManager.Instance.SaveBestStars(levelId, collectedStars);
        LevelProgressManager.Instance.UnlockNextLevel(levelNum);
        Debug.Log($"[GameplayStarManager] Saved {collectedStars} stars for {levelId}");
    }

    // ✅ NEW: Save gameplay coins ke PlayerEconomy
    if (CoinCounterUI.Instance != null)
    {
        CoinCounterUI.Instance.SaveToPlayerEconomy();
        Debug.Log("[GameplayStarManager] ✓ Saved gameplay coins to PlayerEconomy");
    }

    // Trigger event
    OnLevelComplete?.Invoke(collectedStars);

    Debug.Log($"[GameplayStarManager] ✓ Level complete with {collectedStars} stars");
}

    public int GetCollectedStars() => collectedStars;
    public int GetTotalStars() => totalStarsInLevel;
}